import numpy as np

int_array = np.arange(1, 101, 1)
print(int_array)

int_array = np.delete(int_array, 72)  # number 73 gets deleted
print(int_array)

def missing_elements(array_var, number_elements):
    sum1 = (number_elements * (number_elements + 1))/2
    sum2 = sum(array_var)
    diff_outcome = sum1 - sum2

    print()
    print(f"Missing number is {diff_outcome}")


missing_elements(int_array, 100)


